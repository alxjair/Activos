<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gerente</title>
</head>
<body>
    
</body>
</html>